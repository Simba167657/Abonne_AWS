export interface ICarModel {
    model: string;
    years: number[];
}

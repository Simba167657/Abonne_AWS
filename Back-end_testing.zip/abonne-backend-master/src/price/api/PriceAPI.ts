// import { Request, Response } from "express";
// export interface IPriceAPI {
//   handleGetAllPrices(req: Request, res: Response): Promise<void>;
// }

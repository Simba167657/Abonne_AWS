INSERT INTO cities (english_name, arabic_name) VALUES ('Alexandria','الاسكندرية');
INSERT INTO cities (english_name, arabic_name) VALUES ('Cairo','القاهرة');
